"use client";

import React, { useState, Suspense, useRef, useMemo, useEffect, useCallback } from "react";
import styled, { keyframes, css } from "styled-components";
import { Canvas, useFrame, ThreeEvent } from "@react-three/fiber";
import {
  useGLTF,
  Stage,
  OrbitControls,
  Html,
  Center,
  Environment
} from "@react-three/drei";
import {
  TrendingUp,
  Layers,
  AlertTriangle,
  LayoutDashboard,
  Settings,
  XCircle,
  Activity,
  Zap,
  Cpu,
  Thermometer,
  Gauge,
  Bot,
  CheckCircle,
  Database,
  BarChart3,
  ScanLine,
  Droplets,
} from "lucide-react";
import * as THREE from "three";
import { GLTF } from "three-stdlib";
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell
} from 'recharts';

// -----------------------------------------------------------------------------
// [데이터 목업]
const GR2_DATA = [
  { name: '09:00', inspection: 400, error: 24, rate: 0.5 },
  { name: '10:00', inspection: 300, error: 13, rate: 0.8 },
  { name: '11:00', inspection: 200, error: 58, rate: 1.2 },
  { name: '12:00', inspection: 278, error: 39, rate: 1.0 },
  { name: '13:00', inspection: 189, error: 48, rate: 1.5 },
  { name: '14:00', inspection: 239, error: 38, rate: 1.1 },
  { name: '15:00', inspection: 349, error: 43, rate: 0.9 },
];

// -----------------------------------------------------------------------------
// [설정]
const JIG_MODEL_PATH = "/models/final_final_final.glb";
const FLOOR_MODEL_PATH = "/models/final_final_final_final.glb";
const FACTORY_BG_IMAGE = "/images/gmt_back.png"; 

// [기본 이미지]
const DEFAULT_CART_IMAGE = "https://images.unsplash.com/photo-1616401784845-180882ba9ba8?q=80&w=1000&auto=format&fit=crop";

const THEME = {
  primary: "#10b981",
  secondary: "#3b82f6",
  danger: "#ef4444",
  warning: "#f59e0b",
  textMain: "#1e293b",
  textSub: "#64748b",
  whiteCard: "rgba(255, 255, 255, 0.85)",
  accent: "#6366f1",
  bg: '#F3F4F6',
  border: '#E5E7EB',
  success: '#10B981',
  successBg: '#D1FAE5',
  dangerBg: '#FEE2E2',
};

// -----------------------------------------------------------------------------
// [Types]
interface UnitData {
  name: string;
  temp: number;
  load: number;
  status: 'normal' | 'error';
  uuid?: string;
}

interface ApiDataItem {
  대차번호: string;
  INTCART: number;
  시리얼번호: string;
  모델번호: string;
  TIMEVALUE: string;
  R액_압력: string;
  P액_압력: string;
  가조립온도: string;
  발포시간: string;
  FILENAME1: string;
  AI_TIME_STR: string;
  AI_LABEL: number;
  FILEPATH1: string;
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: any[];
  label?: string;
}

// -----------------------------------------------------------------------------
// [Animations]
const slideInRight = keyframes`
  from { opacity: 0; transform: translateX(30px); }
  to { opacity: 1; transform: translateX(0); }
`;

const slideInLeft = keyframes`
  from { opacity: 0; transform: translateX(-30px); }
  to { opacity: 1; transform: translateX(0); }
`;

const slideUp = keyframes`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`;

const slideDown = keyframes`
  from { opacity: 0; transform: translateY(-20px); }
  to { opacity: 1; transform: translateY(0); }
`;

const float = keyframes`
  0% { transform: translateY(0px) translateX(-50%); }
  50% { transform: translateY(-5px) translateX(-50%); }
  100% { transform: translateY(0px) translateX(-50%); }
`;

const modalPop = keyframes`
  from { opacity: 0; transform: scale(0.95); }
  to { opacity: 1; transform: scale(1); }
`;

const blink = keyframes`
  50% { opacity: 0; }
`;

const soundWave = keyframes`
  0% { height: 10%; }
  50% { height: 100%; }
  100% { height: 10%; }
`;

// -----------------------------------------------------------------------------
// [Styled Components]

const PageContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  height: calc(100vh - 64px);
  background-image: url('${FACTORY_BG_IMAGE}');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  background-color: #0f172a;
  color: #f8fafc;
  font-family: 'Pretendard', sans-serif;
  overflow: hidden;
  position: relative;
  &::before {
    content: '';
    position: absolute;
    top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(10, 15, 30, 0.85);
    z-index: 0; pointer-events: none;
  }
`;

const MainContent = styled.main`
  flex: 1; width: 100%; height: 100%;
  position: relative; z-index: 10;
`;

const ViewerContainer = styled.div`
  width: 100%; height: 100%;
  padding-top: 4rem;
  position: relative;
  isolation: isolate;
`;

const GlassPanel = styled.div`
  position: fixed;
  background: ${THEME.whiteCard};
  backdrop-filter: blur(20px) saturate(180%);
  border: 1px solid rgba(255, 255, 255, 0.6);
  border-radius: 20px;
  padding: 16px;
  display: flex; flex-direction: column;
  z-index: 20;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
  pointer-events: auto;
  color: ${THEME.textMain};
  font-family: 'Pretendard', sans-serif;
  will-change: transform;
`;

const TopRightPanel = styled(GlassPanel)`
  top: 5rem; right: 1.5rem; 
  width: 320px; height: 280px; 
  animation: ${slideInRight} 0.8s cubic-bezier(0.22, 1, 0.36, 1) forwards;
`;

const DefectStatusPanel = styled(GlassPanel)`
  top: calc(5rem + 280px + 15px); right: 1.5rem; 
  width: 320px; min-height: 160px;
  animation: ${slideInRight} 0.8s cubic-bezier(0.22, 1, 0.36, 1) 0.2s forwards;
  border-left: 4px solid ${THEME.danger};
`;

const BottomLeftPanel = styled(GlassPanel)`
  bottom: 1.5rem; left: 1.5rem;
  width: 320px; 
  height: 260px; 
  animation: ${slideInLeft} 0.8s cubic-bezier(0.22, 1, 0.36, 1) 0.2s forwards;
  opacity: 0; animation-fill-mode: forwards;
`;

const VisionAnalysisPanel = styled(GlassPanel)`
  bottom: 1.5rem;
  left: calc(1.5rem + 320px + 15px); 
  width: 240px;
  animation: ${slideInLeft} 0.8s cubic-bezier(0.22, 1, 0.36, 1) 0.3s forwards;
  opacity: 0; animation-fill-mode: forwards;
  padding: 0; 
  overflow: hidden;
`;

const HoverInfoPanel = styled(GlassPanel)`
  top: 5rem; left: 1.5rem; width: 260px; 
  padding: 14px; 
  animation: ${slideDown} 0.3s cubic-bezier(0.16, 1, 0.3, 1);
  border-left: 4px solid transparent;
  transition: border-color 0.3s ease, box-shadow 0.3s ease;
  will-change: transform, border-color;
`;

const AIAdvisorPanel = styled.div`
  position: fixed;
  bottom: calc(1.5rem + 260px + 15px); 
  left: 1.5rem;
  width: 320px;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(24px);
  border-radius: 20px;
  box-shadow: 0 20px 50px rgba(99, 102, 241, 0.15), 0 4px 12px rgba(0, 0, 0, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.8);
  padding: 0;
  overflow: hidden;
  z-index: 25;
  animation: ${slideUp} 0.6s cubic-bezier(0.2, 0.8, 0.2, 1);
  display: flex; flex-direction: column;
  font-family: 'Pretendard', sans-serif;
  will-change: transform;
`;

const AIHeader = styled.div`
  background: linear-gradient(135deg, #e0e7ff 0%, #f3f4f6 100%);
  padding: 12px 16px; 
  display: flex; align-items: center; gap: 10px;
  border-bottom: 1px solid rgba(0, 0, 0, 0.03);
`;

const AIBody = styled.div`
  padding: 16px; position: relative; 
`;

const AIMessage = styled.div`
  font-size: 14px; line-height: 1.6; color: ${THEME.textMain}; font-weight: 500;
`;

const WaveBar = styled.div<{ $delay: number }>`
  width: 4px; height: 100%; background: ${THEME.accent}; border-radius: 2px;
  animation: ${soundWave} 1s ease-in-out infinite; animation-delay: ${(p) => p.$delay}s;
`;

const BlinkingCursor = styled.span`
  display: inline-block; width: 2px; height: 14px; background-color: ${THEME.accent};
  margin-left: 4px; vertical-align: middle; animation: ${blink} 1s step-end infinite;
`;

const InfoRow = styled.div`
  display: flex; justify-content: space-between; align-items: center; 
  padding: 8px 0; 
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
  &:last-child { border-bottom: none; }
  .label { display: flex; align-items: center; gap: 6px; font-size: 12px; color: ${THEME.textSub}; font-weight: 500; }
  .value { font-family: 'Pretendard', sans-serif; font-variant-numeric: tabular-nums; font-size: 13px; font-weight: 700; color: ${THEME.textMain}; }
  .status { padding: 2px 6px; border-radius: 4px; font-size: 10px; font-weight: 700; }
`;

const ChartHeader = styled.div`
  display: flex; justify-content: space-between; align-items: flex-start; 
  margin-bottom: 10px;
`;

const ChartTitle = styled.div`
  font-size: 15px; 
  font-weight: 800; color: ${THEME.textMain};
  display: flex; align-items: center; gap: 6px; transition: color 0.3s;
`;
const ChartSubtitle = styled.div`
  font-size: 11px; color: ${THEME.textSub}; font-weight: 500; margin-top: 2px;
`;
const BigNumber = styled.div`
  font-size: 32px; font-weight: 800; color: ${THEME.textMain};
  letter-spacing: -1px; font-family: 'Pretendard', sans-serif; font-variant-numeric: tabular-nums;
`;

const TrendBadge = styled.div<{ $isUp: boolean }>`
  font-size: 12px; font-weight: 700; color: ${(p) => (p.$isUp ? THEME.primary : THEME.danger)};
  display: flex; align-items: center; gap: 4px;
`;

const ChartWrapper = styled.div`
  flex: 1; width: 100%; min-height: 0; position: relative;
`;

const DefectItem = styled.div`
  display: flex; justify-content: space-between; align-items: center;
  padding: 8px; 
  margin-bottom: 6px;
  background: rgba(239, 68, 68, 0.05);
  border: 1px solid rgba(239, 68, 68, 0.2);
  border-radius: 8px;
  &:last-child { margin-bottom: 0; }
`;

const DefectName = styled.div`
  font-weight: 700; color: ${THEME.textMain};
  display: flex; align-items: center; gap: 6px; font-size: 14px;
`;

const DefectTag = styled.div`
  font-size: 11px; font-weight: 700; color: #fff; background: ${THEME.danger};
  padding: 2px 8px; border-radius: 99px;
  display: flex; align-items: center; gap: 4px; animation: ${blink} 2s infinite;
`;

const NavContainer = styled.div`
  position: absolute; top: 1.5rem; left: 50%; transform: translateX(-50%);
  display: flex; gap: 8px; z-index: 20;
  background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(12px);
  padding: 6px; border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.2); box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
`;

const NavButton = styled.button<{ $active: boolean }>`
  background: ${(props) => (props.$active ? 'rgba(255, 255, 255, 0.9)' : 'transparent')};
  color: ${(props) => (props.$active ? '#0f172a' : '#cbd5e1')};
  border: 1px solid ${(props) => (props.$active ? '#fff' : 'transparent')};
  padding: 8px 16px; border-radius: 8px;
  font-size: 14px; font-weight: 700; cursor: pointer;
  transition: all 0.2s ease; font-family: 'Pretendard', sans-serif;
  &:hover {
    color: ${(props) => (props.$active ? '#0f172a' : '#fff')};
    background: ${(props) => (props.$active ? '#fff' : 'rgba(255, 255, 255, 0.1)')};
  }
`;

const InstructionBadge = styled.div`
  position: absolute; bottom: 2rem; left: 50%; transform: translateX(-50%);
  padding: 0.8rem 1.6rem;
  background: rgba(15, 23, 42, 0.8); backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.15); border-radius: 9999px;
  font-size: 0.85rem; font-weight: 500; color: #cbd5e1;
  display: flex; align-items: center; gap: 8px; pointer-events: none; z-index: 90;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3); animation: ${float} 4s ease-in-out infinite;
  span.highlight { color: #38bdf8; font-weight: 700; }
`;

const LoaderOverlay = styled.div`
  position: fixed; inset: 0; display: flex; align-items: center; justify-content: center;
  background: #000000; z-index: 9999; flex-direction: column;
`;

const LoadingBarContainer = styled.div`
  width: 300px; text-align: center;
`;

const LoadingText = styled.div`
  font-size: 15px; color: #cbd5e1; margin-bottom: 12px; display: flex;
  justify-content: space-between; font-family: 'Pretendard', sans-serif;
  strong { color: #38bdf8; }
`;

const Track = styled.div`
  width: 100%; height: 6px; background: #334155; border-radius: 3px; overflow: hidden;
`;

const Fill = styled.div<{ $p: number }>`
  height: 100%; width: ${(props) => props.$p}%;
  background: linear-gradient(90deg, #38bdf8, #818cf8);
  transition: width 0.1s linear; box-shadow: 0 0 10px #38bdf8;
`;

// -----------------------------------------------------------------------------
// [Helpers]

function TransitionLoader({ onFinished }: { onFinished: () => void }) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    let start: number | null = null;
    const duration = 1500;
    let frame: number;
    const animate = (timestamp: number) => {
      if (!start) start = timestamp;
      const progress = timestamp - start;
      const percentage = Math.min((progress / duration) * 100, 100);
      setVal(percentage);
      if (progress < duration) frame = requestAnimationFrame(animate);
      else setTimeout(onFinished, 200);
    };
    frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, [onFinished]);

  return (
    <LoaderOverlay>
      <LoadingBarContainer>
        <LoadingText><span>요청 처리 중...</span><strong>{val.toFixed(0)}%</strong></LoadingText>
        <Track><Fill $p={val} /></Track>
      </LoadingBarContainer>
    </LoaderOverlay>
  );
}

const CustomTooltip = React.memo(({ active, payload, label }: CustomTooltipProps) => {
  if (active && payload && payload.length) {
    return (
      <div style={{ background: 'rgba(255, 255, 255, 0.95)', border: '1px solid #e2e8f0', borderRadius: '12px', padding: '12px', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', minWidth: '140px', fontFamily: 'Pretendard, sans-serif' }}>
        <div style={{ color: '#64748b', fontSize: '12px', marginBottom: '6px', fontWeight: '600' }}>{label}</div>
        {payload.map((p, i) => (
          <div key={i} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px', fontSize: '13px' }}>
            <span style={{ color: '#334155', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <span style={{ width: 6, height: 6, borderRadius: 2, background: p.color }} />{p.name}
            </span>
            <span style={{ color: '#0f172a', fontWeight: 'bold' }}>{p.value}{p.unit || ''}</span>
          </div>
        ))}
      </div>
    );
  }
  return null;
});
CustomTooltip.displayName = "CustomTooltip";

function PreparingModal({ target, onClose }: { target: string | null, onClose: () => void }) {
  const ModalOverlay = styled.div`
    position: fixed; inset: 0; background: rgba(0, 0, 0, 0.6); backdrop-filter: blur(4px);
    display: flex; align-items: center; justify-content: center; z-index: 99999;
  `;
  const ModalBox = styled.div`
    width: 320px; background: rgba(15, 23, 42, 0.95); border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 16px; padding: 24px; text-align: center; box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
    animation: ${modalPop} 0.3s cubic-bezier(0.16, 1, 0.3, 1); position: relative; font-family: 'Pretendard', sans-serif;
  `;
  const CloseButton = styled.button`
    position: absolute; top: 12px; right: 12px; background: none; border: none; color: #64748b;
    cursor: pointer; transition: color 0.2s; &:hover { color: #fff; }
  `;
  if (!target) return null;
  return (
    <ModalOverlay onClick={onClose}>
      <ModalBox onClick={(e) => e.stopPropagation()}>
        <CloseButton onClick={onClose}><XCircle size={24} /></CloseButton>
        <div style={{ width: 60, height: 60, margin: '0 auto 16px', background: 'rgba(148, 163, 184, 0.1)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Settings size={30} color="#94a3b8" />
        </div>
        <h3 style={{ fontSize: '18px', fontWeight: '700', color: '#f8fafc', marginBottom: '8px' }}>시스템 준비 중</h3>
        <p style={{ fontSize: '14px', color: '#94a3b8', lineHeight: '1.5' }}>선택하신 <span style={{ color: '#38bdf8', fontWeight: 'bold' }}>{target} 공정</span> 대시보드는<br />현재 시스템 연동 작업이 진행 중입니다.</p>
        <button onClick={onClose} style={{ marginTop: '20px', padding: '10px 24px', background: '#38bdf8', color: '#0f172a', fontWeight: 'bold', borderRadius: '8px', border: 'none', cursor: 'pointer', fontFamily: 'Pretendard, sans-serif' }}>확인</button>
      </ModalBox>
    </ModalOverlay>
  );
}

// -----------------------------------------------------------------------------
// [3D Logic]
// [수정됨] 바닥 모델: 상호작용 차단
const FloorModel = React.memo(() => {
  const { scene } = useGLTF(FLOOR_MODEL_PATH);
  return <primitive object={scene} raycast={() => null} />;
});
FloorModel.displayName = "FloorModel";

class ModelErrorBoundary extends React.Component<{ fallback: React.ReactNode, children: React.ReactNode }, { hasError: boolean }> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError() { return { hasError: true }; }
  componentDidCatch(error: any) { console.error("3D Model Loading Failed:", error); }
  render() { if (this.state.hasError) return this.props.fallback; return this.props.children; }
}

interface JigModelProps {
  url: string;
  onHoverChange: (data: UnitData | null) => void;
  onStatusUpdate: (units: UnitData[]) => void;
}

function InteractiveJigModel({ url, onHoverChange, onStatusUpdate }: JigModelProps) {
  const { scene } = useGLTF(url);
  const activeIdRef = useRef<string | null>(null);
  const errorMeshesRef = useRef<THREE.Mesh[]>([]); 
  const highlightColor = useMemo(() => new THREE.Color("#38bdf8"), []);
  const errorColor = useMemo(() => new THREE.Color("#ff0000"), []);
  const [sortedLabels, setSortedLabels] = useState<{ id: string, name: string, position: THREE.Vector3 }[]>([]);

  // 시작점 위치 보정 변수
  const OFFSET_START_INDEX = 6; 

  useEffect(() => {
    const meshes: { mesh: THREE.Mesh, position: THREE.Vector3 }[] = [];
    errorMeshesRef.current = []; 
    
    scene.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        const mesh = child as THREE.Mesh;
        const name = mesh.name.toLowerCase();

        // 기존 필터 유지 (혹시 모를 다른 바닥들 제거)
        if (
          name.includes('floor') || name.includes('ground') || name.includes('plane') || 
          name.includes('base') || name.includes('plate') || name.includes('bottom') || 
          name.includes('stand') || name.includes('support') || name.includes('frame') || 
          name.includes('line') || name.includes('rail')
        ) {
          return;
        }

        mesh.castShadow = true; mesh.receiveShadow = true;
        
        // 재질 설정 (기존 동일)
        if (mesh.material) {
          const oldMat = Array.isArray(mesh.material) ? mesh.material[0] : mesh.material;
          const standardMat = oldMat as THREE.MeshStandardMaterial;
          const originalColor = standardMat.color ? standardMat.color : new THREE.Color(0xffffff);
          const newMat = new THREE.MeshPhysicalMaterial({
            color: originalColor, metalness: 0.1, roughness: 0.2, 
            clearcoat: 1.0, clearcoatRoughness: 0.1, side: THREE.DoubleSide
          });
          mesh.material = newMat;
        }
        
        const worldPos = new THREE.Vector3();
        mesh.getWorldPosition(worldPos);
        meshes.push({ mesh, position: worldPos });
      }
    });

    // 정렬 로직 (기존 동일)
    let centerX = 0; let centerZ = 0;
    meshes.forEach(m => { centerX += m.position.x; centerZ += m.position.z; });
    centerX /= meshes.length; centerZ /= meshes.length;

    meshes.sort((a, b) => {
        let angleA = Math.atan2(a.position.z - centerZ, a.position.x - centerX);
        let angleB = Math.atan2(b.position.z - centerZ, b.position.x - centerX);
        if (angleA < 0) angleA += Math.PI * 2;
        if (angleB < 0) angleB += Math.PI * 2;
        return angleB - angleA; 
    });

    const sliceIndex = OFFSET_START_INDEX % meshes.length;
    
    // 1. 일단 정렬된 리스트를 만듭니다.
    const sortedMeshes = [
        ...meshes.slice(sliceIndex),
        ...meshes.slice(0, sliceIndex)
    ];

    // [수정된 부분] 13번째 오브젝트(Index 12) 강제 삭제 로직
    // 이미지에서 GR13으로 잡힌 녀석을 배열에서 물리적으로 빼버립니다.
    if (sortedMeshes.length > 12) {
       // splice(시작인덱스, 개수): 12번 인덱스부터 1개를 제거
       sortedMeshes.splice(12, 1);
    }

    // 에러 시뮬레이션 (기존 동일)
    const errorCount = Math.floor(Math.random() * 4) + 2;
    // 배열 길이가 줄었으므로 sortedMeshes.length를 기준으로 다시 계산
    const shuffledIndices = Array.from({ length: sortedMeshes.length }, (_, i) => i).sort(() => 0.5 - Math.random()).slice(0, errorCount);
    const errorIndicesSet = new Set(shuffledIndices);
    const errorUnitsData: UnitData[] = [];

    // 라벨 생성 (이제 GR13이 빠졌으므로, 뒤에 있던 녀석들이 당겨져서 1~24번이 됩니다)
    const labelsData = sortedMeshes.map((item, index) => {
      const count = index + 1;
      const labelText = `GR${count.toString().padStart(2, '0')}`;
      
      const isError = errorIndicesSet.has(index);
      const temp = isError ? Math.floor(Math.random() * 20) + 80 : Math.floor(Math.random() * 30) + 40;
      const load = isError ? Math.floor(Math.random() * 10) + 90 : Math.floor(Math.random() * 40) + 20;
      
      const unitData: UnitData = { 
          name: labelText, 
          temp, 
          load, 
          status: isError ? 'error' : 'normal', 
          uuid: item.mesh.uuid 
      };
      
      item.mesh.userData = unitData;
      
      if (isError) {
        errorUnitsData.push(unitData);
        errorMeshesRef.current.push(item.mesh);
      }
      
      return { 
          id: item.mesh.uuid, 
          name: labelText, 
          position: item.position.clone().add(new THREE.Vector3(0, 0.8, -0.5)) 
      };
    });

    setSortedLabels(labelsData);
    onStatusUpdate(errorUnitsData);
  }, [scene, onStatusUpdate]);

  // ... (나머지 useFrame, 이벤트 핸들러 등은 기존과 동일) ...

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    const flashIntensity = 1.5 + Math.sin(time * 12) * 1.0;
    errorMeshesRef.current.forEach((mesh) => {
      if (activeIdRef.current !== mesh.uuid) {
        const mat = mesh.material as THREE.MeshPhysicalMaterial;
        mat.emissive.set(errorColor);
        mat.emissiveIntensity = flashIntensity;
      }
    });
  });

  const handlePointerOver = useCallback((e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    document.body.style.cursor = "pointer";
    const mesh = e.object as THREE.Mesh;
    if (mesh.isMesh) {
      activeIdRef.current = mesh.uuid;
      const mat = mesh.material as THREE.MeshPhysicalMaterial;
      mat.emissive.copy(highlightColor);
      mat.emissiveIntensity = 2.0;
      onHoverChange(mesh.userData as UnitData);
    }
  }, [highlightColor, onHoverChange]);

  const handlePointerOut = useCallback((e: ThreeEvent<PointerEvent>) => {
    const mesh = e.object as THREE.Mesh;
    if (activeIdRef.current === mesh.uuid) {
      document.body.style.cursor = "auto";
      activeIdRef.current = null;
      const mat = mesh.material as THREE.MeshPhysicalMaterial;
      if (mesh.userData.status !== 'error') {
        mat.emissiveIntensity = 0;
      }
      onHoverChange(null);
    }
  }, [onHoverChange]);

  return (
    <group>
      <primitive object={scene} onPointerOver={handlePointerOver} onPointerOut={handlePointerOut} />
      {sortedLabels.map((label) => (
        <Html 
            key={label.id} 
            position={label.position} 
            center 
            distanceFactor={15} 
            style={{ pointerEvents: 'none', userSelect: 'none' }}
        >
          <div style={{
            background: 'rgba(0, 0, 0, 0.6)', padding: '2px 6px', borderRadius: '4px',
            border: '1px solid rgba(255, 255, 255, 0.3)', color: 'white', fontSize: '10px',
            fontWeight: 'bold', whiteSpace: 'nowrap', fontFamily: 'Pretendard, sans-serif', 
            backdropFilter: 'blur(2px)',
            marginTop: '20px' 
          }}>
            {label.name}
          </div>
        </Html>
      ))}
    </group>
  );
}

// -----------------------------------------------------------------------------
// [Components] UI Panels

const AIAdvisor = React.memo(({ errors }: { errors: UnitData[] }) => {
  const [message, setMessage] = useState("");
  const [displayMessage, setDisplayMessage] = useState("");
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (errors.length > 0) {
      const target = errors[0];
      let advice = "";
      if (target.temp >= 90) {
        advice = `${target.name} 코어 온도 ${target.temp}°C 감지. 냉각수 순환 펌프 3번 밸브 개방 및 유량 확인이 필요합니다. 즉시 조치바랍니다.`;
      } else if (target.load >= 90) {
        advice = `${target.name} 시스템 부하 ${target.load}% 도달. 입력 프로세스 속도를 20% 감속하고, 백그라운드 캐시를 정리하십시오.`;
      } else {
        advice = `${target.name} 비정상 신호 감지. 센서 교정 작업이 필요할 수 있습니다. 유지보수 팀을 호출하십시오.`;
      }
      setMessage(advice);
      setIndex(0);
      setDisplayMessage("");
    } else {
      setMessage("모든 시스템 정상 가동 중. 특이사항 없습니다.");
      setIndex(0);
      setDisplayMessage("");
    }
  }, [errors]);

  useEffect(() => {
    if (index < message.length) {
      const timeout = setTimeout(() => {
        setDisplayMessage((prev) => prev + message[index]);
        setIndex((prev) => prev + 1);
      }, 30);
      return () => clearTimeout(timeout);
    }
  }, [index, message]);

  return (
    <AIAdvisorPanel>
      <AIHeader>
        <div style={{ width: 40, height: 40, borderRadius: '50%', background: THEME.accent, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: `0 4px 12px ${THEME.accent}60` }}>
          <Bot size={22} color="#fff" />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 12, color: THEME.textSub, fontWeight: 600 }}>SYSTEM ADVISOR</div>
          <div style={{ fontSize: 15, fontWeight: 'bold', color: THEME.textMain }}>Factory AI</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 3, height: 20 }}>
          <WaveBar $delay={0} /> <WaveBar $delay={0.2} /> <WaveBar $delay={0.4} /> <WaveBar $delay={0.1} />
        </div>
      </AIHeader>
      <AIBody>
        <AIMessage>{displayMessage}<BlinkingCursor /></AIMessage>
      </AIBody>
    </AIAdvisorPanel>
  );
});
AIAdvisor.displayName = "AIAdvisor";

const Panels = React.memo(({ hoveredInfo, errorUnits, apiData }: { hoveredInfo: UnitData | null, errorUnits: UnitData[], apiData: ApiDataItem[] }) => {
  const activeUnit = hoveredInfo || (errorUnits.length > 0 ? errorUnits[0] : null) || { name: 'GR01', status: 'normal' };
  const isError = activeUnit.status === 'error';
  const statusColor = isError ? THEME.danger : THEME.success;
  const statusBg = isError ? THEME.dangerBg : THEME.successBg;

  const activeNumber = parseInt(activeUnit.name.replace("GR", ""), 10);
  const matchedData = apiData.find(item => parseInt(item.대차번호) === activeNumber);

  const displayImage = matchedData?.FILEPATH1 || "https://images.unsplash.com/photo-1616401784845-180882ba9ba8?q=80&w=1000&auto=format&fit=crop";
  const displayValue1 = matchedData?.AI_LABEL ? Number(matchedData.AI_LABEL).toFixed(4) : "0.0000";
  const displayValue2 = matchedData?.AI_LABEL ? Number(matchedData.AI_LABEL).toFixed(4) : "0.0000";

  const hoverMatchedData = hoveredInfo 
    ? apiData.find(item => parseInt(item.대차번호) === parseInt(hoveredInfo.name.replace("GR", ""), 10))
    : null;

  const boxes = isError 
    ? [{ top: 40, left: 20, width: 10, height: 10, color: '#EF4444' }]
    : [{ top: 55, left: 65, width: 12, height: 12, color: '#10B981' }];
    
  return (
    <>
      {hoveredInfo && (
        <HoverInfoPanel style={{
          borderLeftColor: hoveredInfo.status === 'error' ? THEME.danger : THEME.primary,
          boxShadow: hoveredInfo.status === 'error' ? `0 8px 32px ${THEME.danger}30` : undefined
        }}>
          <ChartHeader>
            <div>
              <ChartTitle style={{ color: hoveredInfo.status === 'error' ? THEME.danger : THEME.textMain }}>
                <Cpu size={18} color={hoveredInfo.status === 'error' ? THEME.danger : THEME.primary} /> {hoveredInfo.name}
              </ChartTitle>
              <ChartSubtitle>Real-time Sensor Data</ChartSubtitle>
            </div>
          </ChartHeader>

          <InfoRow>
            <div className="label"><Activity size={13} /> 작동 상태</div>
            {hoveredInfo.status === 'error' ? (
              <div className="status" style={{ color: '#fff', background: THEME.danger }}>CHECK</div>
            ) : (
              <div className="status" style={{ color: THEME.primary, background: 'rgba(16, 185, 129, 0.1)' }}>NORMAL</div>
            )}
          </InfoRow>

          <InfoRow>
            <div className="label"><Droplets size={13} /> R액 압력</div>
            <div className="value" style={{ color: THEME.textMain }}>
              {hoverMatchedData?.R액_압력 || '-'} <span style={{fontSize: 10, color: THEME.textSub, fontWeight: 500}}>bar</span>
            </div>
          </InfoRow>

          <InfoRow>
            <div className="label"><Gauge size={13} /> P액 압력</div>
            <div className="value" style={{ color: THEME.textMain }}>
               {hoverMatchedData?.P액_압력 || '-'} <span style={{fontSize: 10, color: THEME.textSub, fontWeight: 500}}>bar</span>
            </div>
          </InfoRow>

           <InfoRow>
            <div className="label"><Thermometer size={13} /> 가조립 온도</div>
            <div className="value" style={{ color: hoveredInfo.status === 'error' ? THEME.danger : THEME.textMain }}>
               {hoverMatchedData?.가조립온도 || '-'} <span style={{fontSize: 10, color: THEME.textSub, fontWeight: 500}}>°C</span>
            </div>
          </InfoRow>
        </HoverInfoPanel>
      )}

      <DefectStatusPanel>
        <ChartHeader>
          <div>
            <ChartTitle style={{ color: THEME.danger }}>
              <AlertTriangle size={16} fill={THEME.danger} stroke="#fff" /> 불량 오브젝트
            </ChartTitle>
            <ChartSubtitle>Overheating Units Alert</ChartSubtitle>
          </div>
          <div style={{ background: THEME.danger, color: 'white', padding: '2px 8px', borderRadius: '12px', fontSize: '10px', fontWeight: 'bold' }}>
            {errorUnits.length} 건
          </div>
        </ChartHeader>
        <div style={{ overflowY: 'auto', maxHeight: '120px', paddingRight: '4px' }}>
          {errorUnits.length > 0 ? (
            errorUnits.map((unit, idx) => (
              <DefectItem key={unit.uuid || idx}>
                <DefectName><span>{unit.name}</span></DefectName>
                <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                  <span style={{ fontSize: '12px', fontWeight: 'bold', color: THEME.danger, fontFamily: 'Pretendard', fontVariantNumeric: 'tabular-nums' }}>{unit.temp}°C</span>
                  <DefectTag>CRITICAL</DefectTag>
                </div>
              </DefectItem>
            ))
          ) : (
            <div style={{ textAlign: 'center', padding: '20px', color: '#94a3b8', fontSize: '12px' }}>현재 감지된 이상 없음</div>
          )}
        </div>
      </DefectStatusPanel>

      <TopRightPanel>
        <ChartHeader>
          <div><ChartTitle><Activity size={16} color={THEME.primary} /> 실시간 검사 현황</ChartTitle><ChartSubtitle>Real-time Monitor</ChartSubtitle></div>
          <div style={{ padding: '2px 8px', background: 'rgba(16, 185, 129, 0.1)', color: THEME.primary, borderRadius: '12px', fontSize: 10, fontWeight: 700 }}>LIVE</div>
        </ChartHeader>
        <div style={{ marginBottom: 16 }}><BigNumber style={{fontSize: 28}}>14,480</BigNumber><TrendBadge $isUp={true}><TrendingUp size={12} /> 전일 대비 2.4% 증가</TrendBadge></div>
        <ChartWrapper>
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={GR2_DATA} margin={{ top: 0, right: 0, left: -25, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 10, fill: THEME.textSub, fontFamily: 'Pretendard' }} tickLine={false} axisLine={false} interval={4} />
              <YAxis yAxisId="L" tick={{ fontSize: 10, fill: THEME.textSub, fontFamily: 'Pretendard' }} tickLine={false} axisLine={false} />
              <YAxis yAxisId="R" orientation="right" tick={{ fontSize: 10, fill: THEME.danger, fontFamily: 'Pretendard' }} tickLine={false} axisLine={false} />
              <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(0,0,0,0.02)' }} />
              <Bar yAxisId="L" dataKey="inspection" barSize={10} radius={[4, 4, 4, 4]}>{GR2_DATA.map((entry, index) => (<Cell key={`cell-${index}`} fill={index === GR2_DATA.length - 1 ? THEME.primary : "#cbd5e1"} />))}</Bar>
              <Line yAxisId="R" type="monotone" dataKey="error" stroke={THEME.danger} strokeWidth={2} dot={false} activeDot={{ r: 4, stroke: '#fff' }} />
            </ComposedChart>
          </ResponsiveContainer>
        </ChartWrapper>
      </TopRightPanel>

      <BottomLeftPanel>
        <ChartHeader><div><ChartTitle><Zap size={16} fill={THEME.textMain} stroke="none" /> 주간 불량률 추이</ChartTitle><ChartSubtitle>Weekly Defect Analysis</ChartSubtitle></div></ChartHeader>
        <div style={{ marginBottom: 8, display: 'flex', alignItems: 'baseline', gap: 8 }}><BigNumber style={{fontSize: 28}}>1.2%</BigNumber><TrendBadge $isUp={true} style={{ color: THEME.primary }}>안정권 유지 중</TrendBadge></div>
        <ChartWrapper>
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={GR2_DATA} margin={{ top: 0, right: 0, left: -25, bottom: 0 }}>
              <defs><linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={THEME.primary} stopOpacity={0.3} /><stop offset="100%" stopColor={THEME.primary} stopOpacity={0} /></linearGradient></defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 10, fill: THEME.textSub, fontFamily: 'Pretendard' }} tickLine={false} axisLine={false} interval={4} />
              <YAxis tick={{ fontSize: 10, fill: THEME.textSub, fontFamily: 'Pretendard' }} unit="%" tickLine={false} axisLine={false} />
              <Tooltip content={<CustomTooltip />} cursor={{ stroke: '#cbd5e1' }} />
              <Area type="monotone" dataKey="rate" stroke={THEME.primary} strokeWidth={2} fill="url(#areaGradient)" />
            </AreaChart>
          </ResponsiveContainer>
        </ChartWrapper>
      </BottomLeftPanel>

      <VisionAnalysisPanel>
          <div style={{ 
            padding: '12px 16px', 
            borderBottom: `1px solid ${THEME.border}`, 
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            backgroundColor: '#F9FAFB'
        }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontSize: '16px', fontWeight: 800, color: THEME.textMain, letterSpacing: '-0.5px' }}>
                    {activeUnit.name || 'GR-??'}
                </span>
                
                <div style={{ 
                    padding: '2px 8px', borderRadius: '16px', 
                    backgroundColor: statusBg, color: statusColor,
                    fontSize: '11px', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '4px'
                }}>
                    {isError ? <AlertTriangle size={10} strokeWidth={3} /> : <CheckCircle size={10} strokeWidth={3} />}
                    {isError ? '불량' : '정상'}
                </div>
            </div>
            
            <ScanLine size={16} color={THEME.textSub} />
        </div>

        <div style={{ padding: '12px 16px 0 16px' }}>
            <div style={{ 
                position: 'relative', width: '100%', height: '120px',
                borderRadius: '12px', overflow: 'hidden', backgroundColor: '#000',
                border: `1px solid ${THEME.border}`, boxShadow: 'inset 0 0 20px rgba(0,0,0,0.2)'
            }}>
                <img 
                    src={displayImage}
                    alt="Factory Cart Analysis" 
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }} 
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1616401784845-180882ba9ba8?q=80&w=1000&auto=format&fit=crop";
                    }}
                />
                {boxes.map((box, idx) => (
                <div key={idx} style={{
                    position: 'absolute',
                    top: `${box.top}%`, left: `${box.left}%`,
                    width: `${box.width}%`, height: `${box.height}%`,
                    border: `2px solid ${box.color}`,
                    boxShadow: `0 0 10px ${box.color}`,
                    zIndex: 10
                }} />
                ))}
            </div>
        </div>

        <div style={{ padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <div style={{ 
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                padding: '8px 10px', borderRadius: '10px', backgroundColor: '#F3F4F6',
                border: `1px solid ${THEME.border}`
            }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <div style={{ padding: '4px', borderRadius: '6px', backgroundColor: '#fff', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
                        <Database size={12} color={THEME.accent} />
                    </div>
                    <span style={{ fontSize: '11px', fontWeight: 600, color: THEME.textSub }}>상반기 평균값</span>
                </div>
                <span style={{ fontSize: '14px', fontWeight: 800, color: THEME.textMain, fontVariantNumeric: 'tabular-nums' }}>
                    {displayValue1}
                </span>
            </div>

            <div style={{ 
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                padding: '8px 10px', borderRadius: '10px', backgroundColor: '#F3F4F6',
                border: `1px solid ${THEME.border}`
            }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <div style={{ padding: '4px', borderRadius: '6px', backgroundColor: '#fff', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
                        <BarChart3 size={12} color={THEME.success} />
                    </div>
                    <span style={{ fontSize: '11px', fontWeight: 600, color: THEME.textSub }}>하반기 평균값</span>
                </div>
                <span style={{ fontSize: '14px', fontWeight: 800, color: THEME.textMain, fontVariantNumeric: 'tabular-nums' }}>
                    {displayValue2}
                </span>
            </div>
        </div>
      </VisionAnalysisPanel>
    </>
  );
});
Panels.displayName = "Panels";

// -----------------------------------------------------------------------------
// [Main Page]
export default function GlbViewerPage() {
  const [initialLoaded, setInitialLoaded] = useState(true);
  const [activeTab, setActiveTab] = useState("GR2");
  const [targetTab, setTargetTab] = useState<string | null>(null);
  const [isNavigating, setIsNavigating] = useState(false);
  const [modalTarget, setModalTarget] = useState<string | null>(null);

  const [hoveredInfo, setHoveredInfo] = useState<UnitData | null>(null);
  const [errorUnits, setErrorUnits] = useState<UnitData[]>([]);
  const [apiData, setApiData] = useState<ApiDataItem[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("http://1.254.24.170:24828/api/DX_API000024");
        const json = await response.json();
        if (json.success) {
          setApiData(json.data);
        } else {
          console.warn("API returned success: false");
        }
      } catch (error) {
        console.error("Failed to fetch DX_API000024:", error);
      }
    };
    fetchData();
  }, []);

  const tabs = ["GR2", "GR3", "GR5", "GR9"];

  const handleTabClick = (tab: string) => {
    if (tab === activeTab || isNavigating) return;
    if (tab === "GR2") {
      setTargetTab(tab);
      setIsNavigating(true);
    } else {
      setModalTarget(tab);
    }
  };

  const handleTransitionComplete = () => {
    if (targetTab) {
      setActiveTab(targetTab);
      setTargetTab(null);
    }
    setIsNavigating(false);
  };

  return (
    <PageContainer>
      <MainContent>
        {isNavigating && <TransitionLoader onFinished={handleTransitionComplete} />}
        <PreparingModal target={modalTarget} onClose={() => setModalTarget(null)} />

        <NavContainer>
          {tabs.map(tab => (
            <NavButton key={tab} $active={activeTab === tab} onClick={() => handleTabClick(tab)}>
              <LayoutDashboard size={14} style={{ display: 'inline-block', marginRight: 6, verticalAlign: 'text-bottom' }} /> {tab} 공정
            </NavButton>
          ))}
        </NavContainer>

        <ViewerContainer>
          
          <AIAdvisor errors={errorUnits} />

          <Panels 
            hoveredInfo={hoveredInfo} 
            errorUnits={errorUnits} 
            apiData={apiData}
          />

          <Canvas
            dpr={[1, 1.5]}
            // [수정] 카메라 위치 반전 (-22, 18, -20) -> 180도 회전
            camera={{ position: [-22, 18, -20], fov: 14 }}
            shadows="soft"
            gl={{
              logarithmicDepthBuffer: true,
              antialias: true,
              powerPreference: "high-performance"
            }}
          >
            <ambientLight intensity={0.5} />
            {/* [수정] 조명 위치도 반전된 카메라에 맞춰 이동 */}
            <directionalLight
              position={[-20, 30, -20]}
              intensity={1.5}
              castShadow
              shadow-mapSize={[4096, 4096]}
              shadow-bias={-0.0001}
              shadow-normalBias={0.05}
            >
              <orthographicCamera attach="shadow-camera" args={[-8, 8, 8, -8]} />
            </directionalLight>

            <Suspense fallback={null}>
              <Stage environment="city" intensity={2.0} adjustCamera={false} shadows={false}>
                <Center position={[5, 0, 4]}>
                  <group position={[0, 0, 0]}>
                    <ModelErrorBoundary fallback={null}>
                      <FloorModel />
                    </ModelErrorBoundary>
                    <ModelErrorBoundary fallback={null}>
                      <InteractiveJigModel
                        url={JIG_MODEL_PATH}
                        onHoverChange={setHoveredInfo}
                        onStatusUpdate={setErrorUnits}
                      />
                    </ModelErrorBoundary>
                  </group>
                </Center>
              </Stage>
              <Environment preset="city" blur={1} background={false} />
            </Suspense>
            <OrbitControls
              target={[-1, 0, 0]}
              makeDefault
              minPolarAngle={0}
              maxPolarAngle={Math.PI / 2.1}
            />
          </Canvas>

          <InstructionBadge>
            <Layers size={14} color="#38bdf8" />
            <span className="highlight">좌클릭</span>: 회전 / <span className="highlight">스크롤</span>: 확대/축소
          </InstructionBadge>
        </ViewerContainer>
      </MainContent>
    </PageContainer>
  );
}

// -----------------------------------------------------------------------------
// [Preload Assets]
useGLTF.preload(JIG_MODEL_PATH);
useGLTF.preload(FLOOR_MODEL_PATH);